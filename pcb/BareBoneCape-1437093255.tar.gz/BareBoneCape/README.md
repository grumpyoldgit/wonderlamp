# BareBone Cape
### A BeagleBone Black Cape Template made in KiCad

![BareBone Cape](beaglebone-cape.png)